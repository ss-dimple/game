module.exports = {
  ...require('mwts/.prettierrc.json'),
  printWidth:120,
  singleQuote:true,
  trailingComma:'all',
  arrowParens:'always',
  endOfLine:'auto'
}
