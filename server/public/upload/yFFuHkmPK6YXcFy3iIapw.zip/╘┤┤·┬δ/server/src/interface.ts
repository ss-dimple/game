/**
 * @description User-Service parameters
 */
export interface ResOp {
  data?: any;
  code?: number;
  message?: string;
}
