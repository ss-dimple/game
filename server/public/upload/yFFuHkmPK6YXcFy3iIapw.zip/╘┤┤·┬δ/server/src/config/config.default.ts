import { MidwayConfig } from '@midwayjs/core';

export default {
  // use for cookie sign key, should change to your own and keep security
  keys: '1672467069450_1111',
  koa: {
    port: 7001,
    globalPrefix: '/api',
  },
  prisma: { url: 'mysql://root:123456@localhost:3306/sail' },
  // jwt 密钥
  jwt: {
    secret: 'mYserverUser230966Checked',
  },
  redis: {
    clients: {
      admin: {
        host: '127.0.0.1',
        port: '6379',
        password: '123456',
        db: 0,
      },
      gamer: {
        host: '127.0.0.1',
        port: '6379',
        password: '123456',
        db: 1,
      },
      user: {
        host: '127.0.0.1',
        port: '6379',
        password: '123456',
        db: 2,
      },
    },
  },
  cors: {
    allowHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    allowMethods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD'],
    credentials: true,
    origin: (req) => {
      const whiteList = ['http://127.0.0.1:8080'];
      // console.log('origin', req.headers.origin);
      if (req.headers.origin) {
        if (whiteList.includes(req.headers.origin)) {
          return req.headers.origin;
        }
        return 'http://localhost:8080';
      } else {
        return '*';
      }
    },
  },
} as MidwayConfig;
