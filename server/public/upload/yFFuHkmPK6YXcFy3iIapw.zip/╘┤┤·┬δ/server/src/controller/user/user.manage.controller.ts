import { Provide, Inject, Controller, Get, Post, Body, ALL } from '@midwayjs/decorator';
import { BaseController, VERIFY_PREFIX_URL, USER_PREFIX_URL } from '../base';
import { UserManageService } from '../../service/user/user.manage.service';
import { UserVerifyService } from '../../service/user/user.verify.service';
import { ResOp } from '../../interface';
import { res, resByPage } from '../../common/utils';
// import { PageUserDto } from '../../dto/user/user.manage';
// import { userInfo } from 'os';

@Provide()
@Controller(`${USER_PREFIX_URL}${VERIFY_PREFIX_URL}/`)
export class UserManegeController extends BaseController {
  @Inject()
  userManageService: UserManageService;

  @Inject()
  userVerifyService: UserVerifyService;

  @Get('/userInfo')
  async getUserInfoByTokenId(): Promise<ResOp> {
    console.log(this.ctx.state.user, 'userinfo');
    return res({
      data: await this.userManageService.getUserManageById(this.ctx.state.user.uid),
    });
  }

  @Get('/logout')
  async logout(): Promise<ResOp> {
    // console.log('logout:', this.ctx.state.admin.uid);
    await this.userVerifyService.clearLoginStatus(this.ctx.state.user.uid);
    return res();
  }

  @Post('/userManage')
  async seachUserOfPage(@Body(ALL) userInfo): Promise<ResOp> {
    // console.log('seach dto:', dto);
    console.log(userInfo, 'search userinfo');
    const list = await this.userManageService.getUserBySearchInfo(userInfo);
    console.log(list, 'list');
    const total = await this.userManageService.getUserSearchCount(userInfo);
    return resByPage(list, total, userInfo.page, userInfo.limit);
  }
}
