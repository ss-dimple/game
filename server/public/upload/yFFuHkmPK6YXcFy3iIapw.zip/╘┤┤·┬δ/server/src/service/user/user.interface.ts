export interface IPageSearchUserResult {
  id: number;
  userno: number;
  username: string;
  sex: number;
  roleId: number;
  gradeId: number;
  classId: number;
}
