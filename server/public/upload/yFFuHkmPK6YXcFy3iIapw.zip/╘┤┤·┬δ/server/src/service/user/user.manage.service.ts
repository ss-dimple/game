import { Provide, Inject } from '@midwayjs/decorator';
import { BaseService } from '../base';
// import {
//   AddAdminDto,
//   EditAdminDto,
//   EditAdminSelfDto,
//   AdminResetPasswordDto,
//   PageAdminUserDto,
// } from '../../dto/admin/user';
import { Utils } from '../../common/utils';
import { PageUserDto } from '../../dto/user/user.manage';
import { IPageSearchUserResult } from '../user/user.interface';
// import { Validate } from '@midwayjs/validate';

@Provide()
export class UserManageService extends BaseService {
  @Inject()
  utils: Utils;

  async getUserManageById(id: number) {
    const result = await this.prisma.user.findUnique({
      where: {
        id: id,
      },
      select: {
        id: true,
        userno: true,
        username: true,
        sex: true,
        gradeId: true,
        classId: true,
        roleId: true,
        // status: true,
      },
    });

    return {
      id: result.id,
      userno: result.userno,
      username: result.username,
      sex: result.sex,
      gradeId: result.gradeId,
      classId: result.classId,
      roleId: result.roleId,
      // status: result.status,
      //   level: result.level,
    };
  }
  async getUserManageByUsername(username: string) {
    const result = await this.prisma.user.findFirst({
      where: {
        username: username,
      },
    });
    return result;
  }

  async getUserBySearchInfo(userInfo): Promise<IPageSearchUserResult[]> {
    const whereObj: any = {};
    userInfo.userno &&
      Object.assign(whereObj, {
        userno: userInfo.userno,
      });
    userInfo.username &&
      Object.assign(whereObj, {
        username: {
          contains: userInfo.username,
        },
      });
    userInfo.sex &&
      Object.assign(whereObj, {
        sex: userInfo.sex,
      });
    userInfo.roleId &&
      Object.assign(whereObj, {
        roleId: userInfo.roleId,
      });
    const result = await this.prisma.user.findMany({
      skip: (userInfo.page - 1) * userInfo.limit,
      take: userInfo.limit,
      where: whereObj,
    });
    console.log(result, '搜索结果');
    const users: IPageSearchUserResult[] = [];
    result.forEach((ele) => {
      users.push({
        id: ele.id,
        userno: ele.userno,
        username: ele.username,
        sex: ele.sex,
        roleId: ele.roleId,
        gradeId: ele.gradeId,
        classId: ele.classId,
      });
    });
    return users;
  }

  async getUserSearchCount(dto: PageUserDto): Promise<number> {
    const whereObj: any = {};
    dto.userno &&
      Object.assign(whereObj, {
        userno: dto.userno,
      });
    dto.username &&
      Object.assign(whereObj, {
        username: {
          contains: dto.username,
        },
      });
    dto.sex &&
      Object.assign(whereObj, {
        sex: dto.sex,
      });
    dto.roleId &&
      Object.assign(whereObj, {
        roleId: dto.roleId,
      });
    return await this.prisma.user.count({
      where: whereObj,
    });
  }
}
