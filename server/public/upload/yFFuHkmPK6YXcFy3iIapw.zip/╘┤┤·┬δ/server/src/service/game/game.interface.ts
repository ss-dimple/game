export interface IPageSearchTypeManageResult {
  id: number;
  typeName: string;
  typeLevel: number;
}
