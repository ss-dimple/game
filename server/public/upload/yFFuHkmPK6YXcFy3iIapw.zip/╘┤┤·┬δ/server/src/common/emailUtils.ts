// import nodemailer from 'nodemailer';
// import { Utils } from './utils'

//  const code = Utils.randomSixCode()

//SMTP客户端配置
// const config = {
//   host: 'smtp.qq.com',
//   post: 465, //端口
//   auth: {
//     user: '2571627530@qq.com', // 邮箱账号
//     pass: 'hoycgigqtzqrebia',
//   },
// };

// //创建一个SMTP客户端对象
// const transporter = nodemailer.createTransport(config);

// //创建一个邮件对象
// const mail = {
//   from: '2571627530<2571627530@qq.com>',
//   content: "亲爱的用户：\n" +
//   "您此次的验证码为：\n\n" +
//   code + "\n\n" +
//   "此验证码5分钟内有效，请立即进行下一步操作。 如非你本人操作，请忽略此邮件。\n" + "感谢您的使用！",
//   to:
// }