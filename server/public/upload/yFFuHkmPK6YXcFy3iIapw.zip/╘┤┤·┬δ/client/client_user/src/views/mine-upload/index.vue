<template>
<div class="main">
    <div class="main-info">
        <div class="main-info-left">
            <div class="main-left-title">
                <span>游戏基本信息</span>
            </div>
            <div class="main-left-form">
                <el-form
                ref="ruleFormRef"
                :model="ruleForm"
                :rules="rules"
                label-width="120px"
                class="demo-ruleForm"
                :size="formSize"
                status-icon
                label-position="left"
                >
                <el-form-item label="游戏名称" prop="name">
                    <el-input maxlength="8" show-word-limit  v-model="ruleForm.name" />
                </el-form-item>
                <el-form-item label="游戏类别" prop="region">
                    <el-select v-model="ruleForm.region" >
                        <el-option label="网络游戏" value="网络游戏" />
                        <el-option label="单机游戏" value="单机游戏" />
                    </el-select>
                </el-form-item>
                <el-form-item label="游戏标签" prop="type">
                    <el-checkbox-group v-model="ruleForm.type">
                        <el-checkbox label="恐怖" name="type" />
                        <el-checkbox label="生存" name="type" />
                        <el-checkbox label="竞赛" name="type" />
                        <el-checkbox label="角色扮演" name="type" />
                    </el-checkbox-group>
                </el-form-item>
                <el-form-item label="审核后是否公开" prop="resource">
                    <el-radio-group v-model="ruleForm.resource">
                        <el-radio label="公开" />
                        <el-radio label="不公开" />
                    </el-radio-group>
                </el-form-item>
                <el-form-item label="游戏概要" prop="summary">
                    <el-input  maxlength="15" show-word-limit  v-model="ruleForm.summary" />
                </el-form-item>
                <el-form-item label="游戏详情" prop="desc">
                    <el-input maxlength="150" show-word-limit  v-model="ruleForm.desc" type="textarea" />
                </el-form-item>
                <!-- <el-form-item>
                    <el-button type="primary" @click="submitForm(ruleFormRef)">
                        Create
                    </el-button>
                    <el-button @click="resetForm(ruleFormRef)">Reset</el-button>
                </el-form-item> -->
            </el-form>
            </div>
        </div>
        <div class="main-info-right">
            <div class="main-right-title">
                <span>游戏宣传主图与安装包</span>
            </div>
            <div class="main-right-img">
              <!-- <el-form-item  prop="imgPath"> -->
              <el-upload
              class="avatar-uploader"
              action="https://run.mocky.io/v3/9d059bf9-4660-45f2-925d-ce80ad6c4d15"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
              :before-upload="beforeAvatarUpload"
            >
              <img v-if="imageUrl" :src="imageUrl" class="avatar" />
              <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
            </el-upload>
          <!-- </el-form-item> -->
            </div>
            <div class="main-right-files">
              <!-- <el-form-item> -->
              <el-upload
              class="upload-demo"
              drag
              action="https://run.mocky.io/v3/9d059bf9-4660-45f2-925d-ce80ad6c4d15"
              multiple
              >
              <el-icon class="el-icon--upload"><upload-filled /></el-icon>
              <div class="el-upload__text">
                Drop file here or <em>click to upload</em>
              </div>
              <template #tip>
                <div class="el-upload__tip">
                  jpg/png files with a size less than 500kb
                </div>
              </template>
            </el-upload>
          <!-- </el-form-item> -->
            </div>
        </div>
    </div>
    <div class="main-images">
      <div class="main-images-title">游戏宣传图</div>
      <div class="main-images-imgList">
        <el-upload
        v-model:file-list="imgList"
        action="https://run.mocky.io/v3/9d059bf9-4660-45f2-925d-ce80ad6c4d15"
        list-type="picture-card"
        :on-preview="handlePictureCardPreview"
        :on-remove="handleRemove"
        >
          <el-icon ><Plus /></el-icon>
        </el-upload>

        <el-dialog v-model="dialogVisible">
          <img w-full :src="dialogImageUrl" alt="Preview Image" />
        </el-dialog>
      </div>
    </div>
    <div class="main-button">
      <div class="main-button-item">
        <el-form-item>
        <el-button size="large"  type="primary" @click="submitForm(ruleFormRef)">
          Create
        </el-button>
        <el-button size="large"  @click="resetForm(ruleFormRef)">Reset</el-button>
        </el-form-item>
      </div>
    </div>
</div>
</template>

<script setup lang="ts" >
import { reactive, ref } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { ElMessage } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'

import type { UploadProps, UploadUserFile } from 'element-plus'
import { UploadFilled } from '@element-plus/icons-vue'

//基本信息
const formSize = ref('default')
const ruleFormRef = ref<FormInstance>()
const ruleForm = reactive({
  name: '',
  region: '',
//   count: '',
//   date1: '',
//   date2: '',
//   delivery: false,
  type: [],
  resource: '',
  summary:'',
  desc: '',
  // path:''
})

const rules = reactive<FormRules>({
  name: [
    { required: true, message: '请输入游戏名称', trigger: 'blur' },
    { min: 3, max: 8, message: 'Length should be 3 to 8', trigger: 'blur' },
  ],
  region: [
    {
      required: true,
      message: '请选择游戏类别',
      trigger: 'change',
    },
  ],
//   count: [
//     {
//       required: true,
//       message: 'Please select Activity count',
//       trigger: 'change',
//     },
//   ],
//   date1: [
//     {
//       type: 'date',
//       required: true,
//       message: 'Please pick a date',
//       trigger: 'change',
//     },
//   ],
//   date2: [
//     {
//       type: 'date',
//       required: true,
//       message: 'Please pick a time',
//       trigger: 'change',
//     },
//   ],
  type: [
    {
      type: 'array',
      required: true,
      message: '请选择游戏标签',
      trigger: 'change',
    },
  ],
  resource: [
    {
      required: true,
      message: 'Please select activity resource',
      trigger: 'change',
    },
  ],
  summary:[
  { required: true, message: '请输入不超15字的游戏概要', trigger: 'blur' },
  { min: 3, max: 15, message: 'Length should be 3 to 15', trigger: 'blur' },
  ],
  desc: [
    { required: true, message: '请输入不超150字的游戏详情', trigger: 'blur' },
    { min: 15, max: 150, message: 'Length should be 15 to 150', trigger: 'blur' },
  ],
  // path:[
  //   { required: true, message: '请上传宣传主图' },
  // ],
})

const submitForm = async (formEl: FormInstance | undefined) => {
  if (!formEl) return
  await formEl.validate((valid, fields) => {
    if (valid) {
      console.log('submit!')
    } else {
      console.log('error submit!', fields)
    }
  })
}

const resetForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.resetFields()
}

const options = Array.from({ length: 10000 }).map((_, idx) => ({
  value: `${idx + 1}`,
  label: `${idx + 1}`,
}))

//上传主图
const imageUrl = ref('')

const handleAvatarSuccess: UploadProps['onSuccess'] = (
  response,
  uploadFile
) => {
  imageUrl.value = URL.createObjectURL(uploadFile.raw!)
}

const beforeAvatarUpload: UploadProps['beforeUpload'] = (rawFile) => {
  if (rawFile.type !== 'image/jpeg') {
    ElMessage.error('Avatar picture must be JPG format!')
    return false
  } else if (rawFile.size / 1024 / 1024 > 2) {
    ElMessage.error('Avatar picture size can not exceed 2MB!')
    return false
  }
  return true
}

//上传图片列表
const imgList = ref<UploadUserFile[]>([])

const dialogImageUrl = ref('')
const dialogVisible = ref(false)

const handleRemove: UploadProps['onRemove'] = (uploadFile, uploadFiles) => {
  console.log(uploadFile, uploadFiles)
}

const handlePictureCardPreview: UploadProps['onPreview'] = (uploadFile) => {
  dialogImageUrl.value = uploadFile.url!
  dialogVisible.value = true
}

</script>

<style scoped>
.main{
    /* border: 1px solid silver ; */
    background-color:silver ;
    /* margin: 8px;
    padding: 10px; */
    width: 80%;
    /* height: 700px; */
    margin-left: 10%;
    /* display: flex; */
}

.main-info{
    border: 1px solid silver;
    /* width: 95%; */
    /* height: 400px; */
    display: flex;
    margin: 8px;
    padding: 10px;
}
.main-info-left{
    border: 1px solid rgb(228, 228, 228);
    background-color: rgb(247, 246, 246);
    /* width: 45%; */
    /* height: 370px; */
    /* display: flex; */
    margin: 5px;
    padding: 5px;
}
.main-left-title{
    /* width: 95%; */
    border: 1px solid silver;
    text-align: left;
    color: black;
    height: 30px;
    margin: 5px;
    padding: 5px;
    font-weight: 600;
    font-size: 20px;
}
.main-left-form{
    border: 1px solid silver;
    margin: 5px;
    padding: 5px;
}
.main-info-right{
    border: 1px solid rgb(228, 228, 228);
    background-color: rgb(247, 246, 246);
    width: 55%;
    /* height: 350px; */
    /* display: flex; */
    margin: 5px;
    padding: 5px;
}
.main-right-title{
    width: 95%;
    border: 1px solid silver;
    color: black;
    text-align: left;
    height: 30px;
    margin: 5px;
    padding: 5px;
    font-weight: 600;
    font-size: 20px;
}
.main-right-img{
    border: 1px solid silver;
    margin: 5px;
    padding: 5px;

}
/* 上传主图样式 */
.avatar-uploader .el-upload {
  border: 1px dashed var(--el-border-color);
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: var(--el-transition-duration-fast);
}

.avatar-uploader .el-upload:hover {
  border-color: var(--el-color-primary);
}

.el-icon.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  text-align: center;
}
.main-right-files{
  border: 1px solid silver;
    margin: 5px;
    padding: 5px;
}

.main-images{
    border: 1px solid rgb(228, 228, 228);
    background-color: rgb(247, 246, 246);
    /* width: 100%; */
    /* height: 270px; */
    /* display: flex; */
    margin: 8px;
    padding: 10px;
}
.main-images-title{
  /* width: 95%; */
    color: black;
    border: 1px solid silver;
    text-align: left;
    height: 30px;
    margin: 5px;
    padding: 5px;
    font-weight: 600;
    font-size: 20px;
}
.main-images-imgList{
  border: 1px solid silver;
  margin: 5px;
  padding: 5px;
}
.main-button{
  border: 1px solid silver;
  /* background-color: rgb(247, 246, 246); */
  margin: 8px;
  padding: 10px;
}
.main-button-item{
  text-align: center;
  /* border: 1px solid silver; */
  margin: 5px;
  padding: 5px;
  margin-left: 45%;
}
</style>