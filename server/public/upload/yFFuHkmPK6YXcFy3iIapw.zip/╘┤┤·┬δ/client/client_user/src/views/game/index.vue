<template>
<div class="main">
  <div class="header-menu">
    <Hometop>
      <Sidebar></Sidebar> 
    </Hometop>
  </div>
    <div class="common-layout">
      <el-container>
        <el-header>
          <div class="header-left">
            <!-- <el-image style="width: 100px; height: 100px" src="../../../public/images/精品-1.jpg" fit="cover" /> -->
            <div class="header-left-img">
              <img src="../../../public/images/精品-1.jpg" alt="" fit="fill" >
            </div>
          </div>
          <div class="header-right">
            <div class="header-right-name">【秒发货】PC中文正版 艾尔登法环 豪华版 国区激活码 CDKey</div>
            <div class="header-right-tag">
              <el-button type="info" plain text bg>
                角色扮演<el-icon class="el-icon--right" ><ArrowRight/></el-icon>
              </el-button>
              <el-button type="info" plain text bg>
                ARPG<el-icon class="el-icon--right" ><ArrowRight/></el-icon>
              </el-button>
            </div>
            <!-- <div class="header-right-desc"> -->
              <div class="header-right-title">“享受克服困境时的成就感吧”</div>
              <div class="header-right-team">创作团队：啊对对小组</div>
            <!-- </div> -->
            <div class="header-right-button">
              <el-button type="primary" plain style="width: 644px; height: 45px;">点击下载</el-button>
            </div>
          </div>
        </el-header>
        <el-container class="middle-layout">
          <el-container>
            <el-main>
              <div class="main-desc">
                <div class="main-desc-title">游戏详情</div>
                <div class="main-desc-info">
                  《艾尔登法环》是一款以正统黑暗奇幻世界为舞台的动作RPG游戏。走进辽阔的场景与地下迷宫探索未知，挑战困难重重的险境，享受克服困境时的成就感吧。不仅如此，登场角色之间的利害关系谱成的群像剧，更是不容错过。充满刺激的辽阔世界
无缝连接的辽阔世界──尽情探索状况多变的开放场景，构造复杂、立体的巨大地下迷宫。(小于150字)

                </div>
              </div>
              <div class="main-images">
                <div class="main-images-title">图片</div>
                <div class="main-images-item">
                  <el-carousel indicator-position="outside">
                    <el-carousel-item v-for="item in 4" :key="item">
                      <h3 text="2xl" justify="center">{{ item }}</h3>
                    </el-carousel-item>
                  </el-carousel>
                </div>
              </div>
            </el-main>
            <el-aside width="200px">Aside</el-aside>
          </el-container>
          <el-footer>
            <div class="footer-comment">
              <div class="footer-comment-info">
                <div class="footer-comment-title">评价</div>
                <div class="footer-comment-grade">
                  <div class="footer-grade-star">
                    <el-rate
                    size="large"
                    v-model="value"
                    disabled
                    show-score
                    text-color="#ff9900"
                    score-template="{value}分"
                    />
                  </div>
                  <div class="footer-grade-button">
                    <el-button type="danger">写评价</el-button>
                  </div>
                </div>
              </div>
              <div class="footer-comment-list">
                <div class="footer-comment-item">
                  <div class="footer-item-left">
                    <div class="footer-left-avatar">
                      <el-avatar
                      src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
                      width="48px" height="48px"
                      />
                    </div>
                  </div>
                  <div class="footer-item-right">
                    <div class=" footer-right-name">阿八八八</div>
                    <div class="footer-right-desc">
                      <span>不光是让我梦回魂1了，简直就是梦回小时候玩游戏无功利之心的原始快乐，发现新地点未知空间的探索冒险怎么能这么带感！！
今年年度最佳预定了，买的ps5版一开始抱怨没有触觉反馈，但是除了这个玩下来内容真的太丰富了，玩了16个小时了，才探索完10分之一的内容，地下城、墓穴、城堡，内容太多了！之后还有一大堆地图和地下世界地图等着我去玩，太强了！</span>
                    </div>
                    <div class="footer-right-more">
                      <div class="footer-more-time">一年前</div>
                      <div class="footer-more-button">
                        <!-- <div class="footer-button-support flex-h" @click="handleClick" :class="isUp?'check':''">
                          <div class="footer-support-img" :class="isUp?'support-img-check':''">
                            <img v-if="isUp" src="../../../public/images/support2.png" alt="" width="50px" height="50px">
                            <img  src="../../../public/images/support1.png" alt="" width="50px" height="50px">
                          </div>
                        </div>
                        <div class="footer-support-num">{{ support }}</div> -->
                      </div>
                    </div>
                  </div>
                  <div class="footer-clear-fix"></div>
                </div>
                <div class="footer-comment-item">
                  <div class="footer-item-left">
                    <div class="footer-left-avatar">
                      <el-avatar
                      src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
                      width="48px" height="48px"
                      />
                    </div>
                  </div>
                  <div class="footer-item-right">
                    <div class=" footer-right-name">阿八八八</div>
                    <div class="footer-right-desc">
                      <span>不光是让我梦回魂1了，简直就是梦回小时候玩游戏无功利之心的原始快乐，发现新地点未知空间的探索冒险怎么能这么带感！！
今年年度最佳预定了，买的ps5版一开始抱怨没有触觉反馈，但是除了这个玩下来内容真的太丰富了，玩了16个小时了，才探索完10分之一的内容，地下城、墓穴、城堡，内容太多了！之后还有一大堆地图和地下世界地图等着我去玩，太强了！</span>
                    </div>
                    <div class="footer-right-more">
                      <div class="footer-more-time">一年前</div>
                      <div class="footer-more-button">
                        <!-- <div class="footer-button-support flex-h" @click="handleClick" :class="isUp?'check':''">
                          <div class="footer-support-img" :class="isUp?'support-img-check':''">
                            <img v-if="isUp" src="../../../public/images/support2.png" alt="" width="50px" height="50px">
                            <img  src="../../../public/images/support1.png" alt="" width="50px" height="50px">
                          </div>
                        </div>
                        <div class="footer-support-num">{{ support }}</div> -->
                      </div>
                    </div>
                  </div>
                  <div class="footer-clear-fix"></div>
                </div>
              </div>
              <div class="footer-comment-more">
                <el-button plain>
                  点击更多<el-icon><ArrowRight /></el-icon>
                </el-button>
              </div>
            </div>
          </el-footer>
        </el-container>
      </el-container>
      <el-backtop :right="20" :bottom="100" style="width:80px;height:80px" >
        <el-icon size="70px" color="gray"><ArrowUp /></el-icon>
   </el-backtop>
  </div>
</div>
</template>

<script lang="ts" setup>
import Hometop from '../../Layout/components/Hometop.vue'
import Sidebar from '../../Layout/components/Sidebar.vue'

import { ref } from 'vue'
//评分
const value = ref(3.7)

//点赞
// const isUp = ref(false)
// const support = ref(0)
// const handleClick=()=>{
//   if(isUp.value==false){
//     support.value=support.value+1
//   }else{
//     support.value=support.value-1
//   }
//   isUp.value=!isUp.value
// }
</script>

<style scoped>
.main{
    /* background-color: #1b1d1f; */
    background: linear-gradient(180deg, #1b1d1f 120px, #FFF 400px);
}
.header-menu{
  /* background-color: #1b1d1f; */
  color: #333;
  text-align: center;
  line-height: 60px;
  height: 70px;
  /* margin: 8px;
  padding: 10px; */
}
.common-layout{
    /* border: 1px solid silver ; */
    /* margin: 8px;
    padding: 10px; */
    /* background-color: #f6f6f7; */
    width: 80%;
    margin-left: 10%;
}

header{
    /* border: 1px solid silver; */
    /* width: 100%; */
    height: 270px;
    display: flex;
    margin: 8px;
    padding: 10px;
}
.header-left{
  width: 39%;
  /* border: 1px solid silver; */
  margin: 8px;
  padding: 8px;
  position: relative;
}

.header-right{
  width: 55%;
  /* border: 1px solid silver; */
  margin: 8px;
  padding: 8px;
  position: relative;
}
.header-right-name{
  /* border: 1px solid black; */
  /* font-size: large; */
  font-size: 28px;
  font-weight: 500;
  line-height: 1em;
  color: #ffffff;
}
.header-right-tag{
  margin: 8px;
}
/* .header-right-desc{
  border: 1px solid black; 
  padding: 5px;
   margin: 5px;
} */
.header-right-title{
  font-size: 18px;
  color: rgb(207, 203, 203);
  margin: 5px;
}
.header-right-team{
  font-size: 16px;
  color: rgb(182, 178, 178);
  /* margin: 5px; */
  margin-left: 5px;
}
.header-right-button{
  margin: 5px;
}
.middle-layout{
    display: flex;
    /* padding: 10px; */
}
aside{
    border: 1px solid silver;
    width: 30%;
    height: 600px;
    margin: 13px;
    padding: 10px;
}
main{
    border: 1px solid silver;
    width: 45%;
    height: 600px;
    margin: 13px;
    padding: 10px;
}
.main-desc{
  height: 140px;
  border: 1px solid silver;
  margin: 8px;
  padding: 8px;
  position: relative;
}
.main-desc-title{
    /* border: 1px solid black; */
    height: 45px;
    text-align: left;
    font-size: large;
    line-height: 40px;
    position: relative;
    padding-left: 11px;
    /* font-family: '正楷'; */
}
.main-desc-title:before{
    background: #024aff;
    content: "";
    height: 40px;
    left: 0;
    position: absolute;
    top: 1px;
    width: 5px;
}
.main-desc-info{
  color: rgb(78, 78, 78);
  font-size: 16px;
  margin: 5px;
}
.main-images{
  height: 370px;
  border: 1px solid silver;
  margin: 8px;
  padding: 8px;
  position: relative;
}
.main-images-title{
  /* border: 1px solid black; */
  height: 45px;
    text-align: left;
    font-size: large;
    line-height: 40px;
    position: relative;
    padding-left: 11px;
    /* font-family: '正楷'; */
}
.main-images-title:before{
    background: #024aff;
    content: "";
    height: 40px;
    left: 0;
    position: absolute;
    top: 1px;
    width: 5px;
}
.main-images-item{
  margin: 5px;
}
.el-carousel__item h3 {
  display: flex;
  color: #475669;
  opacity: 0.75;
  line-height: 300px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}
footer{
    border: 1px solid silver;
    /* width: 100%; */
    height: 430px;
    margin: 8px;
    padding: 10px;
}
.footer-comment-info{
  border: 1px solid silver;
  display: flex;
  margin: 8px;
  padding: 10px;
  /* position: absolute; */
}
.footer-comment-title{
  height: 45px;
    text-align: left;
    font-size: large;
    line-height: 40px;
    position: relative;
    padding-left: 11px;
}
.footer-comment-title:before{
    background: #024aff;
    content: "";
    height: 40px;
    left: 0;
    position: absolute;
    top: 1px;
    width: 5px;
}
.footer-comment-grade{
  /* border: 1px solid silver; */
  margin-right: -100px;
  display: flex;
}
.footer-grade-star{
  right: 300px;
  position: absolute;
}
.footer-grade-button{
  right: 200px;
  position: absolute;
}
.footer-comment-item{
  position: relative;
  border: 1px solid rgba(0,0,0,.1);
  margin: 8px;
  padding: 8px;
  height: 120px;
}
.footer-item-left{
  border: 1px solid rgba(0,0,0,.1);
  border-radius: 50%;
  box-sizing: border-box;
  float: left;
  height: 48px;
  margin: 0 16px 0 0;
  width: 48px;
}
.footer-left-avatar{
  background: 50%/cover no-repeat;
  border-radius: 50%;
  height: 100%;
  width: 100%;
}
.footer-item-right{
  float: left;
  padding: 0;
  width: calc(100% - 64px);
}
.footer-right-name{
  align-items: center;
    display: flex;
    justify-content: flex-start;
    color: #333;
    font-size: 13px;
    font-weight: 700;
    line-height: 13px;
    margin: 0 6px 0 0;
}
.footer-right-desc{
  font-size: 14px;
    line-height: 22px;
    margin: 12px auto 16px;
    word-break: break-word;
}
.footer-right-more{
  align-items: center;
    display: flex;
    justify-content: space-between;
}
.footer-more-time{
  color: #9195a3;
    font-size: 13px;
    line-height: 13px;
    margin: 0 30px 0 0;
}
.footer-more-button{
  align-items: center;
    display: flex;
    justify-content: flex-end;
}
.footer-clear-fix{
  clear: both;
}
.footer-comment-more{
  text-align: center;
  size: large;
}

</style>