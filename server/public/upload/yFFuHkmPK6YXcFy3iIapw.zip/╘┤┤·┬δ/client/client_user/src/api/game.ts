import request from '@/utils/request'

export const getTagList = () =>
  request({
    url: "/game/tagList",
    method: 'get'
  })

  export const getBestList = () =>
  request({
    url: "/game/bestList",
    method: 'get'
  })

  export const getTypeList = () =>
  request({
    url: "/game/typeList",
    method: 'get'
  })

