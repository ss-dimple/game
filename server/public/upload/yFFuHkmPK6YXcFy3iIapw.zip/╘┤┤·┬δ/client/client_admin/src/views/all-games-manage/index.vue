<template>
    游戏管理（管理员）
</template>

<script lang="ts" setup>
    
</script>

<style scoped>
 
</style>